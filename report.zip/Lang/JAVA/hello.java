class test{
	public static void main(String args[]){
		system.out.println("Hello JAVA world\n");
	}
}
