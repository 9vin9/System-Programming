#include "students.h"

void dbcreate(char *);
void dbquery(char *);
void dbupdate(char *);

int main(int argc, char *argv[]){
	int seletion;

	if(argc < 2) {
		fprintf(stderr, "사용법 : %s file\n", argv[0]);
		exit(1);
	}

	while(1){
		printf("1. db생성\n2. db질의\n3. db갱신\n0. 종료\n");
		printf("메뉴 선택 >>> ");
		scanf("%d", &seletion);
		        
		if(seletion == 1){
			dbcreate(argv[1]);
		}
		else if(seletion == 2){
			dbquery(argv[1]);
		}
		else if(seletion == 3){
			dbupdate(argv[1]);
		}
		else if(seletion == 0){
			exit(0);
		}
		else{
			printf("잘못된 값입니다.");
			printf("해당 메뉴는 존재하지 않습니다. 다시 입력해주세요.");
		}

	}
}

